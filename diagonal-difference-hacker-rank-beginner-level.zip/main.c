#include<stdio.h>
#include<stdlib.h>
int main (void)
{
    int matrix[100][100],order,i,j,diagonal1=0,diagonal2=0;
    scanf("%d",&order);
    ;
    for(i=0;i<order;i++)
    {
        for(j=0;j<order;j++)
        {
            scanf("%d",&matrix[i][j]);
            if(i==j)
            {
                diagonal1=diagonal1+matrix[i][j];
            }
            if(i+j==(order-1))
            {
                diagonal2=diagonal2+matrix[i][j];
            }
        }
    }
    printf("%d %d\n",diagonal1,diagonal2);
    printf("%d",abs(diagonal1-diagonal2));
}

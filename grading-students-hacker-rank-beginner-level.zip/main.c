#include<stdio.h>
int main()
{
    int count,i,marks[60];
    scanf("%d",&count);
    for(i=0;i<count;i++)
    {
        scanf("%d",&marks[i]);
        
    }
    for(i=0;i<count;i++)
    {
        int a=marks[i]/5;
        a++;
        int b=a*5;
        if(marks[i]>=38){
            if(((b)-marks[i])<3)
            {
                printf("%d\n",b);
            }
            else
            {
                printf("%d\n",marks[i]);
            }
        }
        else{ 
            printf("%d\n",marks[i]);
        }
    }
}

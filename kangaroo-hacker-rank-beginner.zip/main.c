#include<stdio.h>
int main()
{
    double x1,x2,v1,v2;
    scanf("%lf %lf %lf %lf",&x1,&v1,&x2,&v2);
    do
    {
        x1=x1+v1;
        x2=x2+v2;
    }while(x1!=x2 && x1<=1000000000 && x2<=1000000000);
    
    if(x1==x2)
    {
        printf("YES");
    }
    else
    {
        printf("NO");
    }
    return 0;
}
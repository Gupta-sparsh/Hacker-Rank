#include<stdio.h>
int main()
{
    int size,A[200000],i,one=0,two=0,three=0,four=0,five=0;
    scanf("%d",&size);
    for(i=0;i<size;i++)
    {
        scanf("%d",&A[i]);
        if(A[i]==1)
        { one=one+1;}
        else if(A[i]==2)
        { two=two+1;}
        else if(A[i]==3)
        { three=three+1;}
        else if(A[i]==4)
        { four=four+1;}
        if(A[i]==5)
        { five=five+1; }
    }
    if(one>=two && one>=three && one>=four && one>=five)
    {printf("1");}
    if(two>one && two>=three && two>=four && two>=five)
    {printf("2");}
    if(three>two && three>one && three>=four && three>=five)
    {printf("3");}
    if(four>two && four>three && four>one &&four>=five)
    {printf("4");}
    if(five>two && five>three && five>one &&five>four)
    {printf("5");}
    
    
        
    
}
